import { Router, Request, Response } from 'express'
import { prisma } from '../services/prisma.js'
import { requireAuth } from '../middleware/auth.js'
import { requireAdmin } from '../middleware/admin.js'
import { success, fail } from '../utils/response.js'
import {
  MEMBERSHIP_PLAN,
  MEMBERSHIP_STATUS,
  USER_PAYMENT_STATUS,
  USER_ROLE,
  isExamType,
  isMembershipPlan,
  isUserRole,
} from '../constants/domain.js'
import { formatUserForClient } from '../utils/userPresenter.js'
import { PAYMENT_CONFIG_STATUS } from '../constants/domain.js'
import { getOrCreatePaymentConfig } from './payment.js'
import { ChinaumsRequestError } from '../services/chinaums.js'
import {
  PaymentRefundError,
  refreshPaymentRefund,
  requestFullPaymentRefund,
} from '../services/paymentRefund.js'

export const adminRouter = Router()

adminRouter.use(requireAuth, requireAdmin)

function parsePaymentAmount(value: unknown): number | null {
  const amount = Number(value)
  if (!Number.isInteger(amount) || amount < 1 || amount > 100000000) return null
  return amount
}

function formatPaymentConfig(config: {
  firstMonthlyPriceCents: number
  monthlyPriceCents: number
  yearlyPriceCents: number
  status: string
  updatedBy: string | null
  updatedAt: Date
}) {
  return { ...config, updatedAt: config.updatedAt.toISOString() }
}

function formatPaymentRefund(refund: {
  id: string
  refundOrderNo: string
  amountCents: number
  reason: string
  status: string
  providerRefundNo: string | null
  failureCode: string | null
  failureMessage: string | null
  operatorId: string
  refundedAt: Date | null
  createdAt: Date
  updatedAt: Date
}) {
  return {
    ...refund,
    refundedAt: refund.refundedAt?.toISOString() || null,
    createdAt: refund.createdAt.toISOString(),
    updatedAt: refund.updatedAt.toISOString(),
  }
}

// 支付策略配置
adminRouter.get('/payment-config', async (_req, res) => {
  try {
    const config = await getOrCreatePaymentConfig()
    res.json(success(formatPaymentConfig(config)))
  } catch (error) {
    console.error('[admin] payment config error:', error)
    res.status(500).json(fail('获取支付策略失败'))
  }
})

// 保存支付策略后，前台支付弹窗立即读取最新价格。
adminRouter.put('/payment-config', async (req, res) => {
  try {
    const firstMonthlyPriceCents = parsePaymentAmount(req.body.firstMonthlyPriceCents)
    const monthlyPriceCents = parsePaymentAmount(req.body.monthlyPriceCents)
    const yearlyPriceCents = parsePaymentAmount(req.body.yearlyPriceCents)
    const status = req.body.status
    if (firstMonthlyPriceCents === null || monthlyPriceCents === null || yearlyPriceCents === null) {
      res.status(422).json(fail('价格必须是大于 0 的整数分'))
      return
    }
    if (status !== PAYMENT_CONFIG_STATUS.ACTIVE && status !== PAYMENT_CONFIG_STATUS.INACTIVE) {
      res.status(422).json(fail('无效的支付策略状态'))
      return
    }
    if (firstMonthlyPriceCents > monthlyPriceCents) {
      res.status(422).json(fail('首次按月价格不能高于正常月价格'))
      return
    }

    const config = await prisma.paymentConfig.upsert({
      where: { id: 'default' },
      create: {
        id: 'default',
        firstMonthlyPriceCents,
        monthlyPriceCents,
        yearlyPriceCents,
        status,
        updatedBy: req.user!.userId,
      },
      update: {
        firstMonthlyPriceCents,
        monthlyPriceCents,
        yearlyPriceCents,
        status,
        updatedBy: req.user!.userId,
      },
    })
    res.json(success(formatPaymentConfig(config)))
  } catch (error) {
    console.error('[admin] update payment config error:', error)
    res.status(500).json(fail('保存支付策略失败'))
  }
})

// 支付订单列表
adminRouter.get('/payment-orders', async (req, res) => {
  try {
    const page = parsePositiveInt(req.query.page, 1)
    const pageSize = parsePositiveInt(req.query.pageSize, 20, 100)
    const status = typeof req.query.status === 'string' && req.query.status ? req.query.status : undefined
    const where = status ? { status } : {}
    const total = await prisma.paymentOrder.count({ where })
    const totalPages = Math.ceil(total / pageSize)
    const safePage = totalPages > 0 ? Math.min(page, totalPages) : 1
    const list = await prisma.paymentOrder.findMany({
      where,
      include: {
        user: { select: { username: true, email: true } },
        refunds: {
          orderBy: { createdAt: 'desc' },
          take: 1,
          select: {
            id: true,
            refundOrderNo: true,
            amountCents: true,
            reason: true,
            status: true,
            providerRefundNo: true,
            failureCode: true,
            failureMessage: true,
            operatorId: true,
            refundedAt: true,
            createdAt: true,
            updatedAt: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      skip: (safePage - 1) * pageSize,
      take: pageSize,
    })
    res.json(success({
      list: list.map((order) => {
        const { providerPayload: _providerPayload, ...safeOrder } = order
        return {
          ...safeOrder,
          latestRefund: order.refunds[0] ? formatPaymentRefund(order.refunds[0]) : null,
          refunds: undefined,
          createdAt: order.createdAt.toISOString(),
          updatedAt: order.updatedAt.toISOString(),
          expiresAt: order.expiresAt.toISOString(),
          paidAt: order.paidAt?.toISOString() || null,
          closedAt: order.closedAt?.toISOString() || null,
        }
      }),
      pagination: {
        page: safePage,
        pageSize,
        total,
        totalPages,
        hasPrev: safePage > 1,
        hasNext: totalPages > 0 && safePage < totalPages,
      },
    }))
  } catch (error) {
    console.error('[admin] payment orders error:', error)
    res.status(500).json(fail('获取支付订单失败'))
  }
})

// 管理员全额退款
adminRouter.post('/payment-orders/:orderNo/refunds', async (req, res) => {
  try {
    const reason = typeof req.body.reason === 'string' ? req.body.reason.trim() : ''
    if (reason.length < 2 || reason.length > 255) {
      res.status(422).json(fail('退款原因长度应为 2 到 255 个字符', 'PAYMENT_REFUND_REASON_INVALID'))
      return
    }
    const refund = await requestFullPaymentRefund({
      orderNo: req.params.orderNo,
      operatorId: req.user!.userId,
      reason,
    })
    res.json(success(formatPaymentRefund(refund)))
  } catch (error) {
    console.error('[admin] payment refund error:', error)
    if (error instanceof PaymentRefundError) {
      res.status(error.httpStatus).json(fail(error.message, error.code))
      return
    }
    if (error instanceof ChinaumsRequestError) {
      res.status(502).json(fail(error.message, error.code))
      return
    }
    res.status(500).json(fail('发起退款失败', 'PAYMENT_REFUND_FAILED'))
  }
})

// 管理员主动查询退款
adminRouter.post('/payment-refunds/:refundOrderNo/query', async (req, res) => {
  try {
    const refund = await refreshPaymentRefund(req.params.refundOrderNo)
    res.json(success(formatPaymentRefund(refund)))
  } catch (error) {
    console.error('[admin] payment refund query error:', error)
    if (error instanceof PaymentRefundError) {
      res.status(error.httpStatus).json(fail(error.message, error.code))
      return
    }
    if (error instanceof ChinaumsRequestError) {
      res.status(502).json(fail(error.message, error.code))
      return
    }
    res.status(500).json(fail('查询退款失败', 'PAYMENT_REFUND_QUERY_FAILED'))
  }
})

interface RevenueCostPayload {
  rechargeItem: string
  amount: number
  operator: string
  occurredAt: Date
  reimbursementStatus: string
  remark: string | null
}

type RevenueCostPayloadResult =
  | { data: RevenueCostPayload }
  | { error: string }

function buildMembershipEndDate(plan: string, start: Date): Date {
  const end = new Date(start)
  if (plan === MEMBERSHIP_PLAN.YEARLY) {
    end.setFullYear(end.getFullYear() + 1)
  } else {
    end.setMonth(end.getMonth() + 1)
  }
  return end
}

function formatAdminUserForClient<T extends { role: string; paymentStatus?: string | null; memberships?: any[] }>(user: T) {
  const formatted = formatUserForClient(user)
  if (!user.memberships) return formatted
  return {
    ...formatted,
    memberships: user.memberships.map((membership) => ({
      ...membership,
      startsAt: membership.startsAt.getTime(),
      endsAt: membership.endsAt.getTime(),
    })),
  }
}

function parsePositiveInt(value: unknown, fallback: number, max?: number): number {
  const parsed = Number.parseInt(String(value ?? ''), 10)
  const safeValue = Number.isFinite(parsed) && parsed > 0 ? parsed : fallback
  return max ? Math.min(safeValue, max) : safeValue
}

function parseRevenueCostPayload(body: Record<string, unknown>): RevenueCostPayloadResult {
  const {
    rechargeItem,
    amount,
    operator,
    occurredAt,
    reimbursementStatus = 'unreimbursed',
    remark,
  } = body
  const numericAmount = Number(amount)
  const costDate = new Date(String(occurredAt))
  const normalizedRechargeItem = typeof rechargeItem === 'string' ? rechargeItem.trim() : ''
  const normalizedOperator = typeof operator === 'string' ? operator.trim() : ''
  const normalizedReimbursementStatus = typeof reimbursementStatus === 'string' ? reimbursementStatus.trim() : ''
  const normalizedRemark = typeof remark === 'string' && remark.trim() ? remark.trim() : null

  if (!normalizedRechargeItem) {
    return { error: '无效的成本项' }
  }
  if (!Number.isFinite(numericAmount) || numericAmount < 0) {
    return { error: '无效的金额' }
  }
  if (!normalizedOperator) {
    return { error: '无效的操作人' }
  }
  if (Number.isNaN(costDate.getTime())) {
    return { error: '无效的时间' }
  }
  if (!normalizedReimbursementStatus) {
    return { error: '无效的报销情况' }
  }
  if (normalizedRemark && normalizedRemark.length > 500) {
    return { error: '备注不能超过 500 个字符' }
  }

  return {
    data: {
      rechargeItem: normalizedRechargeItem,
      amount: numericAmount,
      operator: normalizedOperator,
      occurredAt: costDate,
      reimbursementStatus: normalizedReimbursementStatus,
      remark: normalizedRemark,
    },
  }
}

// 用户列表
adminRouter.get('/users', async (req: Request, res: Response) => {
  try {
    const page = parsePositiveInt(req.query.page, 1)
    const pageSize = parsePositiveInt(req.query.pageSize, 20, 100)
    const total = await prisma.user.count()
    const totalPages = Math.ceil(total / pageSize)
    const safePage = totalPages > 0 ? Math.min(page, totalPages) : 1
    const users = await prisma.user.findMany({
      select: {
        id: true,
        username: true,
        email: true,
        role: true,
        paymentStatus: true,
        diagnosticUsed: true,
        createdAt: true,
        memberships: {
          select: {
            id: true,
            examType: true,
            plan: true,
            status: true,
            startsAt: true,
            endsAt: true,
          },
          orderBy: { endsAt: 'desc' },
        },
      },
      orderBy: { createdAt: 'desc' },
      skip: (safePage - 1) * pageSize,
      take: pageSize,
    })
    res.json(success({
      list: users.map(formatAdminUserForClient),
      pagination: {
        page: safePage,
        pageSize,
        total,
        totalPages,
        hasPrev: safePage > 1,
        hasNext: totalPages > 0 && safePage < totalPages,
      },
    }))
  } catch (err) {
    console.error('[admin] users error:', err)
    res.status(500).json(fail('服务器错误'))
  }
})

// 更新用户角色
adminRouter.put('/users/:id/role', async (req: Request, res: Response) => {
  try {
    const { role } = req.body
    if (!isUserRole(role)) {
      res.status(422).json(fail('无效的角色'))
      return
    }

    const user = await prisma.user.update({
      where: { id: req.params.id },
      data: { role },
      select: { id: true, username: true, email: true, role: true, paymentStatus: true },
    })
    res.json(success({ user: formatAdminUserForClient(user) }))
  } catch (err) {
    console.error('[admin] update role error:', err)
    res.status(500).json(fail('服务器错误'))
  }
})

// 更新用户权限
adminRouter.put('/users/:id/access', async (req: Request, res: Response) => {
  try {
    const { role, membership } = req.body
    const userId = req.params.id
    if (!isUserRole(role)) {
      res.status(422).json(fail('无效的角色'))
      return
    }

    const requestedExamTypes: unknown[] = Array.isArray(membership?.examTypes) ? membership.examTypes : []
    const plan = membership?.plan
    if (requestedExamTypes.length > 0 && !isMembershipPlan(plan)) {
      res.status(422).json(fail('无效的会员套餐'))
      return
    }
    if (requestedExamTypes.some((examType) => !isExamType(examType))) {
      res.status(422).json(fail('无效的考试类型'))
      return
    }
    const examTypes = requestedExamTypes as string[]

    const now = new Date()
    const endsAt = examTypes.length > 0 ? buildMembershipEndDate(plan, now) : null

    const user = await prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: userId },
        data: {
          role,
          ...(role === USER_ROLE.STUDENT && examTypes.length > 0
            ? { paymentStatus: USER_PAYMENT_STATUS.PAID }
            : {}),
        },
      })

      // 后台手动授权是追加语义：未选中的现有权益不在本次操作中取消。
      for (const examType of examTypes) {
        const active = await tx.userMembership.findFirst({
          where: {
            userId,
            examType,
            status: MEMBERSHIP_STATUS.ACTIVE,
            startsAt: { lte: now },
            endsAt: { gt: now },
          },
          orderBy: { endsAt: 'desc' },
        })
        if (active) {
          continue
        }
        await tx.userMembership.create({
          data: { userId, examType, plan, startsAt: now, endsAt: endsAt!, status: MEMBERSHIP_STATUS.ACTIVE },
        })
      }

      return tx.user.findUnique({
        where: { id: userId },
        select: {
          id: true,
          username: true,
          email: true,
          role: true,
          paymentStatus: true,
          diagnosticUsed: true,
          createdAt: true,
          memberships: {
            select: {
              id: true,
              examType: true,
              plan: true,
              status: true,
              startsAt: true,
              endsAt: true,
            },
            orderBy: { endsAt: 'desc' },
          },
        },
      })
    })

    res.json(success({ user: user ? formatAdminUserForClient(user) : null }))
  } catch (err: any) {
    if (err?.code === 'P2025') {
      res.status(404).json(fail('用户不存在'))
      return
    }
    console.error('[admin] update access error:', err)
    res.status(500).json(fail('服务器错误'))
  }
})

// 成本记录
adminRouter.get('/revenue-costs/getList', async (req: Request, res: Response) => {
  try {
    const page = parsePositiveInt(req.query.page, 1)
    const pageSize = parsePositiveInt(req.query.pageSize, 20, 100)
    const total = await prisma.revenueCost.count()
    const totalPages = Math.ceil(total / pageSize)
    const safePage = totalPages > 0 ? Math.min(page, totalPages) : 1
    const costs = await prisma.revenueCost.findMany({
      orderBy: { occurredAt: 'desc' },
      skip: (safePage - 1) * pageSize,
      take: pageSize,
    })
    res.json(success({
      list: costs,
      pagination: {
        page: safePage,
        pageSize,
        total,
        totalPages,
        hasPrev: safePage > 1,
        hasNext: totalPages > 0 && safePage < totalPages,
      },
    }))
  } catch (err) {
    console.error('[admin] revenue costs error:', err)
    res.status(500).json(fail('服务器错误'))
  }
})

// 成本导入
adminRouter.post('/revenue-costs', async (req: Request, res: Response) => {
  try {
    const parsed = parseRevenueCostPayload(req.body)
    if ('error' in parsed) {
      res.status(422).json(fail(parsed.error))
      return
    }

    const cost = await prisma.revenueCost.create({
      data: parsed.data,
    })
    res.json(success({ cost }))
  } catch (err) {
    console.error('[admin] create revenue cost error:', err)
    res.status(500).json(fail('服务器错误'))
  }
})

// 成本编辑
adminRouter.put('/revenue-costs/:id', async (req: Request, res: Response) => {
  try {
    const parsed = parseRevenueCostPayload(req.body)
    if ('error' in parsed) {
      res.status(422).json(fail(parsed.error))
      return
    }

    const cost = await prisma.revenueCost.update({
      where: { id: req.params.id },
      data: parsed.data,
    })
    res.json(success({ cost }))
  } catch (err: any) {
    if (err?.code === 'P2025') {
      res.status(404).json(fail('成本记录不存在'))
      return
    }
    console.error('[admin] update revenue cost error:', err)
    res.status(500).json(fail('服务器错误'))
  }
})
